let mongoose = require('mongoose');
let test_dbSchema = mongoose.Schema({
    id:Number,
    testName:String,
    testQuestions:[String],
    testDuration:String,
},{collection:'test'});
module.exports=mongoose.model('test',test_dbSchema);